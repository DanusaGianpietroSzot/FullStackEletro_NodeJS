ReactDOM.render(
    <Loja />,
    document.getElementById('root')
)
