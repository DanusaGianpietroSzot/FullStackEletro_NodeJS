ReactDOM.render(
    <Contato />,
    document.getElementById('root')
)
