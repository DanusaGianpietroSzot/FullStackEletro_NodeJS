const Loja = () => {
    return (
        <React.Fragment>
            <Header />
            <CardLojas />
            <Footer />
        </React.Fragment>
    );
}