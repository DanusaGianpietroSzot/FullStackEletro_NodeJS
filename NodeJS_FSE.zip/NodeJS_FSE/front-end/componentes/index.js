ReactDOM.render(
    <Home />,
    document.getElementById('root')
)
