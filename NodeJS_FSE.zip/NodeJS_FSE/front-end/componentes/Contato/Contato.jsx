const Contato = () => {
    return (
        <React.Fragment>
            <Header />
            <MeiosDeContato />
            <CardComentario />
            <Footer />
        </React.Fragment>
    );
}
