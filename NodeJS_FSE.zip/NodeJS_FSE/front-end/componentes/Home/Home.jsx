const Home = () => {
    return (
        <React.Fragment>
            <Header />
            <Card />
            <Footer />
        </React.Fragment>
    );
}