<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Full Stack Eletro</title>
    </head>
    <body>
        <h1>[ERROR] - Página não localizada!</h1>
    </body>
</html>